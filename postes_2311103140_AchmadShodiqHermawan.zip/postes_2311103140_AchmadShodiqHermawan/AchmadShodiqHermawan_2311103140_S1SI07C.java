/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package achmadshodiqhermawan_2311103140_s1si.pkg07.c;

/**
 *
 * @author User
 */
public class AchmadShodiqHermawan_2311103140_S1SI07C {

    /**
     * @AchmadShodiq_2311103140
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
        ManajemenTaman manajementaman = new manajementaman;
    System.out.println(Tanaman);
    }
    
}
