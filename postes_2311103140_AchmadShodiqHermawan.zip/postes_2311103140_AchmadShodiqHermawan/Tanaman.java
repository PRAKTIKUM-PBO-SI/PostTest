/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package achmadshodiqhermawan_2311103140_s1si.pkg07.c;

/**
 *
 * @achmadShodiq_2311103140
 */
public class Tanaman {
        public class Produk {
    private String nama;
    private String jenis;
    private String atributTambahan;
    private int jumlah;

    // Constructor
    public Produk(String nama, String jenis, String atributTambahan, int jumlah) {
        this.nama = nama;
        this.jenis = jenis;
        this.atributTambahan = atributTambahan;
        this.jumlah = jumlah;
    }

    
    public String nama() {  
        return nama;
    }
    public void Nama(String nama) {
        this.nama = nama;
    }
    public String Jenis() {
        return jenis;
    }
    public void Jenis(String jenis) {
        this.jenis = jenis;
    }

    public String AtributTambahan() {
        return atributTambahan;
    }

    public void AtributTambahan(String atributTambahan) {
        this.atributTambahan = atributTambahan;
    }

    public int Jumlah() {
        return jumlah;
    }

    public void Jumlah(int jumlah) {
        this.jumlah = jumlah;
    }

    // Metode untuk menampilkan informasi Tanaman
    public void tampilkanInfo() {
        System.out.println("Nama Produk: " + nama);
        System.out.println("Jenis Produk: " + jenis);
        System.out.println("Atribut Tambahan: " + atributTambahan);
        System.out.println("Jumlah: " + jumlah);
    }
        }
}



