/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package achmadshodiqhermawan_2311103140_s1si.pkg07.c;

/**
 *
 * @author User
 */
public class ManajemenTaman {
    ArrayList<Tanaman> daftarTanaman = new ArrayList <>();
    
}
