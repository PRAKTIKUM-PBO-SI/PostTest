
package pkg2211103067_teddyputratama_posttest;
import java.util.Scanner;
/**
 *
 * @author ACER
 */
public class Tanaman {
    String nama;
    Int jumlah;
    String jenis;
    String atributTanaman;
    
        public Tanaman(String nama, Int jumlah, String jenis,String atributTanaman) {
        this.nama = nama;
        this.jumlah = jumlah;
        this.jenis = jenis;
        this.atributTanaman = atributTanaman;
        }
      public void tampilkanDataTanaman (){
        System.out.println(" nama tanaman :"  + nama);
        System.out.println(" jumlah tanaman :"  + jumlah);
        System.out.println(" jenis tanaman :"  + jenis);
        System.out.println(" atribut tambahan :"  + atributTanaman);
    }
}
