/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg2211103067_teddyputratama_posttest;

/**
 *
 * @author Teddy Putratama
 * 2211103067
 */
public class Main {

public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ManejementTaman ManajementTaman = new ManajementTaman(); 
        
            while();
            System.out.println("1. Tambah Bunga :" );
            System.out.println("2. Tambah Pohon :" );
            System.out.println("3. Tampilkan Semua Tanaman :" );
            System.out.println("4. Keluar :" );
    }
    
}
