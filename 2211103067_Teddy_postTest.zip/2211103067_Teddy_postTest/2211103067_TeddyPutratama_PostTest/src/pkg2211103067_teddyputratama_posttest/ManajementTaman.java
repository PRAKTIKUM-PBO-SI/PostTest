
package pkg2211103067_teddyputratama_posttest;

/**
 *
 * @author Teddy Putratama
 * 2211103067
 * 07 C
 */
public class ManajementTaman {
Arraylist<tanaman>
daftarTanaman = new Arraylist;
}
 public static void main (String[] args){
    Menu[] jumlahTanamanBunga;
    int tambahTanamanPohon;
    int tampilkanSemuaTanaman;
    int keluar;
 