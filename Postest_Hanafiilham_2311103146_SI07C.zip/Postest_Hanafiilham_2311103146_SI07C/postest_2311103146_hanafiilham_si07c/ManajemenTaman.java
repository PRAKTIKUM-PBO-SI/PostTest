/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.postest_2311103146_hanafiilham_si07c;

/**
 *
 * @author hanaf
 */
// Hanafi Ilham 2311103146 SI07C
import java.util.ArrayList;
public class ManajemenTaman {
    ArrayList<Tanaman> daftarTanaman;
    
    public ManajemenTaman() {
    daftarTanaman = new ArrayList<>();
    }
    
    // Tambah tanaman
    public void tambahTanaman(Tanaman tanaman){
        daftarTanaman.add(tanaman);
        System.out.println("Tanaman berhasil ditambahkan!");
    }
    
    // Tampilkan 
    public void tampilkanSemuaTanaman() {
        
    }
}
