/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.postest_2311103146_hanafiilham_si07c;

/**
 *
 * @author hanaf
 */
// Hanafi Ilham 2311103146 SI07C
public class Tanaman {
    String nama;
    int jumlah;
    String jenis;
    String atributTambahan;

    public Tanaman(String nama, int jumlah, String jenis, String atributTambahan) {
        this.nama = nama;
        this.jumlah = jumlah;
        this.jenis = jenis;
        this.atributTambahan = atributTambahan;
    }
    
    public void tampilkanData() {
         System.out.print("Nama Tanaman :" + nama);
         System.out.print("Jumlah Tanaman :" + jumlah);
         System.out.print("Jenis Tanaman :" + jenis);
         System.out.print("Atribut Tambahan :" + atributTambahan);
    }
}
