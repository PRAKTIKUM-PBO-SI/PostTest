/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.postest_2311103146_hanafiilham_si07c;

/**
 *
 * @author hanaf
 */
// Hanafi Ilham 2311103146 SI07C
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ManajemenTaman manajemenTaman = new ManajemenTaman();
        char pilihan;
        
        do {
            System.out.println("===== Menu Manajemen Tanaman =====");
            System.out.println("1. Tambah Bunga");
            System.out.println("2. Tambah Pohon");
            System.out.println("3. Tampilkan Semua Tanaman");
            System.out.println("4. Keluar");
            
            pilihan = input.nextIn();
            input.nextLine();
            
            //switch
            switch(pilihan) {
                System.out.println("")
            }
            
        } while
}
