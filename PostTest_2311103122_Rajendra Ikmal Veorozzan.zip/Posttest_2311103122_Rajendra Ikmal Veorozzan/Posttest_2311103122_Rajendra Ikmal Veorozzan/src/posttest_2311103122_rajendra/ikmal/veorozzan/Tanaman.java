/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package posttest_2311103122_rajendra.ikmal.veorozzan;

/**
 *
 * @author Rajendra Ikmal Veorozzan
 * 2311103122
 * S1Si07C
 */
public class Tanaman {
    String nama;
    int jumlah;
    String jenis;
    String atributTambahan;
    
    public Tanaman(String nama,int jumlah,String jenis,String atributTambahan){
        this.nama = nama;
        this.jenis = jenis;
        this.atributTambahan = atributTambahan;
    }
    public void tampilkanInfoTanaman(){
        System.out.println("nama tanaman: "+nama);
        System.out.println("jenis tanaman: "+nama);
        System.out.println("Atribut Tambahan: "+atributTambahan);
        
                
    }
}
