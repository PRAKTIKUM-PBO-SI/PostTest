/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package posttest_2311103122_rajendra.ikmal.veorozzan;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author ASUS
 */
public class ManajemenTanaman {
    private static ArrayList<Tanaman> daftarTanaman;
    
    public ManajemenTanaman (){
        daftarTanaman = new ArrayList <>();
    }
    
    public void tambahTanaman(Scanner scanner){
        System.out.println("masukan nama tanaman: ");
        String nama = scanner.nextLine();
        System.out.println("masukan jenis tanaman: ");
        String jenis = scanner.nextLine();
        System.out.println("masukan atribut tambahan: ");
        String atributTambahan = scanner.nextLine();
        
    Tanaman tanamanBaru = new Tanaman(nama, jenis, atributTambahan);
    daftarTanaman.add(tanamanBaru);
    System.out.println("tanaman berhasil ditambahkan");
    }
    
    public void tampilkanSemuaTanaman(){
        if(daftarTanaman.isEmpty()){
            System.out.println("tidak ada tanaman yang terdaftar");
        } else {
            
        
        }
    }
