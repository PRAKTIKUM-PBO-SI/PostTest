/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package posttest_2311103122_rajendra.ikmal.veorozzan;

/**
 *
 * @author Rajendra Ikmal Veorozzan
 * 2311103122
 * S1Si07C
 */
public class Posttest_2311103122_RajendraIkmalVeorozzan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
